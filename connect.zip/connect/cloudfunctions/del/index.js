// 云函数入口文件
const cloud = require('wx-server-sdk')
//引入mysql操作模块
const mysql = require('mysql2/promise')
cloud.init()
exports.main = async(event, context) => {
  try {
    //数据库信息
    const connection = await mysql.createConnection({
      host: "rm-8vb610h67fsa7nzl7fo.mysql.zhangbei.rds.aliyuncs.com",
      database: "ivoisea",
      port:3306,
      user: "webcommon1",
      password: "wuzhikeji123",
      charset:'utf8',
    })
    
    connection.connect();
    
    var  userDelSql = 'DELETE FROM test WHERE id = ?';
    var  userDelSql_Params = event.id;
    //删除
 
    connection.query(userDelSql,userDelSql_Params,function (err, result) {
 
        if(err){
          return err;
        }       
        return result; 
    });

    connection.end();

  } catch (err) {
    console.log("链接错误", err)
    return err;
  }
}