// 云函数入口文件
const cloud = require('wx-server-sdk')
//引入mysql操作模块
const mysql = require('mysql2/promise')
cloud.init()
exports.main = async(event, context) => {
  try {
    //数据库信息
    const connection = await mysql.createConnection({
      host: "rm-8vb610h67fsa7nzl7fo.mysql.zhangbei.rds.aliyuncs.com",
      database: "ivoisea",
      port:3306,
      user: "webcommon1",
      password: "wuzhikeji123",
      charset:'utf8',
    })
    
    var  userGetSql = 'SELECT * FROM test';
    //查找
 
    const tempResult =	new Promise((resolve,reject)=>{
      // 开连接
      connection.connect();
      // 执行sql
      connection.query(userGetSql,(err,result)=>{
      // 利用resolve、reject来处理result和err，向外抛，且二者自带return功能
                if(err){
                    reject(err);
                }
                // 成功
                resolve(result);
      })
    });
        // 关闭连接
        connection.end();
        // 返回结果
         return tempResult;

  } catch (err) {
    console.log("链接错误", err)
    return err;
  }
}