//app.js
App({
  onLaunch:function(){
    wx.cloud.init({
      env:"notes-u95a7"
    })
  }
})