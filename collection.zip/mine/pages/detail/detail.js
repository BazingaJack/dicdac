let dianzan = false;
let shoucang = false;
let ID = ''
Page({
  data:{
    detail:'',
    imgUrl:"../images/star2.png",
    dianzanUrl:"../images/zan-no.png"
  },
    onLoad(options){
      ID = options.id
           console.log("详情页接受的id",ID)
           wx.cloud.database().collection("homelist")
           .doc(ID)
           .get()
           .then(res=>{
              console.log("详情页成功",res)
              shoucang=res.data.shoucang
              dianzan=res.data.dianzan
              this.setData({
                detail:res.data,
                imgUrl: shoucang ? "../images/star.png" : "../images/star2.png",
                dianzanUrl: dianzan ? "../images/zan-yes.png" : "../images/zan-no.png"
              })
           })
           .catch(res=>{
              console.log("详情页失败",res)
           })
    },
    //收藏点击
    clickMe(){
      shoucang = !shoucang
      this.setData({
        imgUrl: shoucang ? "../images/star.png" : "../images/star2.png"
      })
      
      wx.cloud.callFunction({
        name:"shoucang",
        data:{
          action:"shoucang",
          id:ID,
          shoucang:shoucang
        }
      })
      .then(res=>{
        console.log("改变收藏状态成功",res)
      })
      .catch(res=>{
        console.log("改变收藏状态失败",res)
      })

    },
    //点赞点击
    clickMe2(){
      dianzan = !dianzan
      this.setData({
        dianzanUrl: dianzan ? "../images/zan-yes.png" : "../images/zan-no.png"
      })
      wx.cloud.callFunction({
        name:"shoucang",
        data:{
          action:"dianzan",
          id:ID,
          dianzan:dianzan
        }
      })
      .then(res=>{
        console.log("小程序改变点赞状态成功",res)
      })
      .catch(res=>{
        console.log("小程序改变点赞状态失败",res)
      })

    }

})