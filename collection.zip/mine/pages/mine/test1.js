// pages/test1/test1.js
Page({
  data: {
      username:"布仁呼",
      userimage:"/pages/images/wechat.jpg",
      list:[
         {
           name:"收藏",
           src:"cloud://notes-u95a7.6e6f-notes-u95a7-1301883224/icon/star2.png",
           id:"01",
           url:"../shoucang/shoucang"
         },
         {
          name:"相册",
          src:"cloud://notes-u95a7.6e6f-notes-u95a7-1301883224/icon/111.png",
          id:"02",
          url:"../photos/photos"
        },
        {
          name:"卡包",
          src:"cloud://notes-u95a7.6e6f-notes-u95a7-1301883224/icon/money.png",
          id:"03",
          url:"../package/package"
        },
        {
          name:"支付",
          src:"cloud://notes-u95a7.6e6f-notes-u95a7-1301883224/icon/6.png",
          id:"04",
          url:"../purchase/purchase"
        },
        {
          name:"设置",
          src:"cloud://notes-u95a7.6e6f-notes-u95a7-1301883224/icon/setting.png",
          id:"05",
          url:"../settings/settings"
        }
      ]
  },
  // getuser(){
  //   // wx.getUserInfo({

  //   //   complete: (res) => {
  //   //     console.log(res),
  //   //     this.setData({
  //   //        username:res.userInfo.nickName,
  //   //        userimage:res.userInfo.avatarUrl
  //   //     })
  //   //   }

  //   // })
  //   wx.navigateTo({
  //     url:'../index/index',
  //   })
  // },
  onLoad: function (options) {
    var that=this;
    wx.getUserInfo({
      success:function(res){
        console.log(res);
        that.setData({
          userimage:res.userInfo.avatarUrl,
          username:res.userInfo.nickName
        })
      }
    })
  },
  goto(e){
     var url = e.currentTarget.dataset.url;
     wx.navigateTo({
       url: url,

     })
  }


  
})
