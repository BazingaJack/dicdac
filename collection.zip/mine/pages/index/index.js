let shoucang = false
let dianzan = false
Page({

  data:{
    imgUrl:"../images/star2.png",
    dianzanUrl:"../images/zan-no.png"
  },
  clickMe(){
    if(shoucang){
      this.setData({
        imgUrl:"../images/star.png"
      })
      shoucang = false;
    }
    else{
      this.setData({
        imgUrl:"../images/star2.png"
      })
      shoucang = true;
    }
  },
  clickMe2(){
      if(dianzan){
        this.setData({
          dianzanUrl:"../images/zan-yes.png"
        })
        dianzan = false;
      }
      else{
        this.setData({
          dianzanUrl:"../images/zan-no.png"
        })
        dianzan = true;
      }
  }
})