Page({
  data:{
    datalist:[]
  },
  // 每次进该页面都会执行onLoad方法
  onLoad(){
    //因为使用了=>函数，所以可以直接使用this
    wx.cloud.database().collection('homelist')
    .where({
      shoucang:true
    })
    .get()
    .then(res => {
      console.log("获取成功",res)
      this.setData({
        datalist:res.data
      })
    })
    .catch(res=>{
      console.log("获取失败",res)
    })
  },
  //跳转到详情页
  goDetail(event){
     console.log("点击获取的数据",event.currentTarget.dataset.item._id)
     wx.navigateTo({
       url: '/pages/detail/detail?id='+event.currentTarget.dataset.item._id,
     })
  }
})