const db=wx.cloud.database();
var inputValue=''; //搜索框输入的值
Page({
  /**
   * 页面的初始数据
   */
  data: {
    list:['手语新闻','学习资讯','聋人相关信息'],
    clickNumber:0,
    
    dataObj:'',//搜出来的东西

    sercherStorage: [],  
    StorageFlag: false, //显示搜索记录标志位
  },
  //点击上方文字  切换
  centerTap:function(event) {
    var cur = event.detail.x;//点击的偏移量
    var singleNavWidth = wx.getSystemInfoSync().windowWidth * 33 / 100;//每个tab选项宽度占33%                     
    this.setData({
        clickNumber: parseInt(cur / singleNavWidth)
    })
  },
  //切换上方文字
  changeSwipe:function(event) {
    var type = event.detail.current;
    this.setData({
      clickNumber: type
    });
  },

  //获取输入框的输入信息
  myInput: function (res) {
    this.setData({
      inputValue: res.detail.value,
    })
  },
  //开始搜索,查询数据库
  searching:function(res){
    db.collection("shou").where({
      pinyin:inputValue
    }).get()
    .then(res=>{
      console.log(res);
      this.setData({
        dataObj:res.data
        
      })
      console.log(res);
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})